#include<stdio.h>
#include"freertos/FreeRTOS.h"
#include"freertos/task.h"

#include"ili9341_driver.h"

void app_main(void)
{
    //spi_init();

    //ili9341 init all
    ili9341_init();

    uint16_t*data=(uint16_t*)malloc(128*128*sizeof(uint16_t));

    for(uint32_t i=0;i<128*128;++i)
    {
        data[i]=0x0000;
    }
    //ili9341 flash color
    ili9341_flash(0,0,160-1,80-1,data);
}
