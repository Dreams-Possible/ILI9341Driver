//enable spi driver
#if 1
#ifndef SPI_DRIVER_H
#define SPI_DRIVER_H

//include
#include "driver/spi_master.h"

//spi init
void spi_init();

#endif//#ifndef SPI_DRIVER_H
#endif//#if 1